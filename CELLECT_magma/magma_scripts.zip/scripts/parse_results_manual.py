#!/usr/bin/env python3
import pandas as pd
import os
from glob import glob
import argparse
import logging

def parse_and_combine(BASE_OUTPUT_DIR):
    BASE_OUTPUT_DIR = os.path.abspath(BASE_OUTPUT_DIR)
    RESULTS_OUTPUT_DIR = os.path.join(BASE_OUTPUT_DIR, "results")
    os.makedirs(RESULTS_OUTPUT_DIR, exist_ok=True)

    logging.info(f"Parsing CELLECT outputs in {BASE_OUTPUT_DIR}/out/ ...")

    # ================== Prioritization ==================
    files = glob(os.path.join(BASE_OUTPUT_DIR, 'out', 'prioritization', '*cell_type_results.txt'))
    if files:
        logging.info(f"Combining {len(files)} prioritization files")
        combined = pd.DataFrame()
        for f in files:
            df = pd.read_csv(f, sep='\t', header=0)
            metadata = os.path.basename(f).replace('.cell_type_results.txt','').split('__')
            df['gwas'] = metadata[-1]
            combined = pd.concat([combined, df])
        specificity_annotation = combined['Name'].str.split('__', expand=True)
        combined['specificity_id'] = specificity_annotation[0]
        combined['annotation'] = specificity_annotation[1]
        combined = combined[['gwas', 'specificity_id', 'annotation', 'Coefficient', 'Coefficient_std_error', 'Coefficient_P_value']]
        combined.rename(columns={'Coefficient':'beta','Coefficient_std_error':'beta_se','Coefficient_P_value':'pvalue'}, inplace=True)
        combined.sort_values(['gwas','specificity_id'], inplace=True)
        combined.to_csv(os.path.join(RESULTS_OUTPUT_DIR,'prioritization.csv'), index=False)

    # ================== Conditional ==================
    files = glob(os.path.join(BASE_OUTPUT_DIR, 'out', 'conditional', '*cell_type_results.txt'))
    if files:
        logging.info(f"Combining {len(files)} conditional files")
        combined = pd.DataFrame()
        for f in files:
            df = pd.read_csv(f, sep='\t', header=0)
            metadata = os.path.basename(f).replace('.cell_type_results.txt','').split('__')
            df['gwas'] = metadata[1]
            df['conditional_annotation'] = metadata[-1]
            combined = pd.concat([combined, df])
        specificity_annotation = combined['Name'].str.split('__', expand=True)
        combined['specificity_id'] = specificity_annotation[0]
        combined['annotation'] = specificity_annotation[1]
        combined = combined[['gwas','specificity_id','conditional_annotation','annotation','Coefficient','Coefficient_std_error','Coefficient_P_value']]
        combined.rename(columns={'Coefficient':'beta','Coefficient_std_error':'beta_se','Coefficient_P_value':'pvalue'}, inplace=True)
        combined.sort_values(['gwas','specificity_id'], inplace=True)
        combined.to_csv(os.path.join(RESULTS_OUTPUT_DIR,'conditional.csv'), index=False)

    # ================== Heritability ==================
    files = glob(os.path.join(BASE_OUTPUT_DIR, 'out', 'h2', '*.results'))
    if files:
        logging.info(f"Combining {len(files)} heritability files")
        combined = pd.DataFrame()
        for f in files:
            df = pd.read_csv(f, sep='\t', header=0)
            df = df.tail(1)
            metadata = os.path.basename(f).replace('.results','').split('__')
            df['specificity_id'] = metadata[0]
            df['gwas'] = metadata[1]
            df['annotation'] = metadata[-1]
            combined = pd.concat([combined, df])
        combined = combined[['gwas','specificity_id','annotation','Prop._SNPs','Prop._h2','Prop._h2_std_error','Enrichment','Enrichment_std_error','Enrichment_p']]
        combined.rename(columns={'Enrichment':'h2_enrichment','Enrichment_std_error':'h2_enrichment_se','Enrichment_p':'h2_enrichment_pvalue'}, inplace=True)
        combined.sort_values(['gwas','specificity_id'], inplace=True)
        combined.to_csv(os.path.join(RESULTS_OUTPUT_DIR,'heritability.csv'), index=False)

    # ================== Heritability intervals ==================
    files = glob(os.path.join(BASE_OUTPUT_DIR, 'out', 'h2', '*results_intervals'))
    if files:
        logging.info(f"Combining {len(files)} heritability intervals files")
        combined = pd.DataFrame()
        for f in files:
            df = pd.read_csv(f, sep='\t', header=0)
            df['q'] = range(df.shape[0])
            metadata = os.path.basename(f).replace('.results_intervals','').split('__')
            df['specificity_id'] = metadata[0]
            df['gwas'] = metadata[1]
            annotation = metadata[-1].split('.')
            annotation = '.'.join(annotation[:-1])
            df['annotation'] = annotation
            combined = pd.concat([combined, df])
        combined = combined[['gwas','specificity_id','annotation','q','h2g','h2g_se','prop_h2g','prop_h2g_se','enr','enr_se','enr_pval']]
        combined.to_csv(os.path.join(RESULTS_OUTPUT_DIR,'heritability_intervals.csv'), index=False)

    # ================== Effector genes ==================
    files = glob(os.path.join(BASE_OUTPUT_DIR, 'out', '*effector_genes.txt'))
    if files:
        logging.info(f"Combining {len(files)} effector genes files")
        combined = pd.DataFrame()
        for f in files:
            df = pd.read_csv(f, sep='\t', header=0)
            metadata = os.path.basename(f).replace('.effector_genes.txt','').split('__')
            df['gwas'] = metadata[-1]
            combined = pd.concat([combined, df])
        combined.sort_values(['gwas','specificity_id'], inplace=True)
        combined.to_csv(os.path.join(RESULTS_OUTPUT_DIR,'effector_genes.csv'), index=False)

    logging.info("All results combined successfully!")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Combine CELLECT/MAGMA output files into single CSVs")
    parser.add_argument('--base_output_dir', required=True, help='Base CELLECT output directory containing out/ folder')
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO)
    parse_and_combine(args.base_output_dir)
