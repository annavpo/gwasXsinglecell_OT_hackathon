#!/usr/bin/env python3
import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.tools.tools as sm_tools
import os
import argparse

def fit_LM(specificity_id, annotation_name, X, y):
    X = sm_tools.add_constant(X)  # add intercept
    model = sm.OLS(y, X).fit()

    # One-sided p-value for the annotation coefficient
    pval = model.pvalues[1] / 2  
    coef = model.params[1]
    se = model.bse[1]

    results = {
        "Name": specificity_id + "__" + annotation_name,
        "Coefficient": coef,
        "Coefficient_std_error": se,
        "Coefficient_P_value": pval
    }

    return results

def main(magma_file, es_matrix_file, specificity_matrix_name, gwas_name, base_output_dir, exclude_mhc=False):
    print(f"Fitting linear model between MAGMA ZSTATs and ES matrix '{specificity_matrix_name}' for GWAS '{gwas_name}'")

    # Load MAGMA ZSTATs
    df_magma = pd.read_csv(magma_file, sep=r'\s+', header=1)

    # Exclude MHC region if requested
    if exclude_mhc:
        old_len = len(df_magma)
        df_magma = df_magma[(df_magma['START'] < 28477797) | 
                            (df_magma['STOP'] > 33448354) | 
                            (df_magma['CHR'] != 6)]
        print(f"{old_len - len(df_magma)} MHC genes excluded.")

    # Load Expression Specificity Matrix
    es_mu = pd.read_csv(es_matrix_file, header=0)
    
    es_mu.rename(columns={'EnsemblID':'GENE'}, inplace=True)
    print(df_magma.columns)
    print(es_mu.columns)
    # Merge on GENE
    merged = df_magma.merge(es_mu, on='GENE')
    
    y = merged['ZSTAT']  # dependent variable

    results_list = []
    for col in es_mu.columns:
        if col == 'GENE':
            continue
        X = merged[[col]]
        res = fit_LM(specificity_matrix_name, col, X, y)
        results_list.append(res)

    df_res = pd.DataFrame(results_list)

    # Prepare output directories
    outdir = os.path.join(base_output_dir, "out")
    subdir = os.path.join(outdir, "prioritization")
    os.makedirs(subdir, exist_ok=True)

    # Save results
    outname = f"{specificity_matrix_name}__{gwas_name}.cell_type_results.txt"
    fullname = os.path.join(subdir, outname)
    df_res.to_csv(fullname, sep='\t', index=False)
    print(f"Results saved to {fullname}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Prioritize cell-type annotations for MAGMA ZSTATs")
    parser.add_argument("--magma_file", required=True, help="MAGMA gene-level ZSTATs file")
    parser.add_argument("--es_matrix_file", required=True, help="Expression specificity matrix file")
    parser.add_argument("--specificity_matrix_name", required=True, help="Name of the ES matrix")
    parser.add_argument("--gwas_name", required=True, help="Name of the GWAS")
    parser.add_argument("--base_output_dir", required=True, help="Base output directory")
    parser.add_argument("--exclude_mhc", action="store_true", help="Exclude MHC genes")
    args = parser.parse_args()

    main(args.magma_file, args.es_matrix_file, args.specificity_matrix_name,
         args.gwas_name, args.base_output_dir, args.exclude_mhc)
