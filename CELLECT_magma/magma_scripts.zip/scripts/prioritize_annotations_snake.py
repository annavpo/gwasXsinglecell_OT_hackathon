import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.tools.tools as sm_tools
import os

def fit_LM(specificity_id, annotation_name, X, y):
    X = sm_tools.add_constant(X)  # add intercept
    model = sm.OLS(y, X).fit()

    pval = model.pvalues[1] / 2  # one-sided p-value for the annotation coefficient
    coef = model.params[1]
    se = model.bse[1]

    results = {
        "Name": specificity_id + "__" + annotation_name,
        "Coefficient": coef,
        "Coefficient_std_error": se,
        "Coefficient_P_value": pval
    }

    return results






########################################################## MAIN ###############################################################

### Enable logging
snake_log_obj = snakemake.log # class(snakemake.log) = 'snakemake.io.Log
sys.stdout = open(str(snake_log_obj), "w") # could not find better ways than calling str(snake_log_obj) to get the log filepath

### Get the parameters from snakemake
specificity_matrix_name = snakemake.params['specificity_matrix_name']      # ES matrix name
specificity_matrix_file = snakemake.params['specificity_matrix_file']      # ES MU file path
gwas_name = snakemake.params['gwas_name']				   # GWAS name
base_output_dir = snakemake.params['base_output_dir']			   # base directory for all the outputs
exclude_mhc = snakemake.params['exclude_mhc'] 	                           # exclude the MHC region or not

print("Fitting linear model between MAGMA ZSTATs and ES matrix '" + specificity_matrix_name + "' for GWAS '" + gwas_name + "': ")

### Load MAGMA ZSTATs
df_magma = pd.read_csv(base_output_dir + "/precomputation/" + gwas_name + "/" + gwas_name + ".resid_correct_all.gsa.genes.out", sep= '\s+', header = 1)

### Exclude the MHC region if necessary
if exclude_mhc:
	old_len = len(df_magma)
	# using one of De Morgan's laws from Boolean Algebra: NOT (A & B) = (NOT A) OR (NOT B)
	df_magma = df_magma[(df_magma['START'] < 28477797) | (df_magma['STOP'] > 33448354) | (df_magma['CHR'] != 6)]
	print(str(old_len - len(df_magma)) + " MHC genes excluded.")

### Expression Specificity Metrics
es_mu = pd.read_csv(specificity_matrix_file, header = 0)

# Prepare data - align by gene or index
# For example, assuming both df_magma and es_mu have 'GENE' column:
merged = df_magma.merge(es_mu, on='GENE')

y = merged['ZSTAT']  # or whatever column is the dependent variable

results_list = []

for col in es_mu.columns:
    if col == 'GENE':
        continue  # skip gene column
    
    X = merged[[col]]
    res = fit_LM(specificity_matrix_name, col, X, y)
    results_list.append(res)

df_res = pd.DataFrame(results_list)

### Save the results for the given specificity_id and GWAS
outname = specificity_matrix_name + "__" + gwas_name + ".cell_type_results.txt"
outdir = base_output_dir + "/out"
subdir = outdir + "/prioritization"
if not os.path.exists(outdir):              # create the directory manually (to_csv() creates a file if it does not exist, but not a directory)
	print("Creating a directory " + outdir)
	os.mkdir(outdir) 
if not os.path.exists(subdir):		    # add the subdirectory
	print("Creating a directory " + subdir)
	os.mkdir(subdir)	
fullname = os.path.join(subdir, outname)

print("Saving the results...")
df_res.to_csv(fullname, sep = '\t', index = False)
print("The results are saved as " + fullname)
