import pandas as pd
import numpy as np
import os
import scipy.stats as st
import argparse

def get_pvals(df_magma):
    '''
    Convert Z stats to p-values
    '''
    df_magma["P"] = 1 - st.norm.cdf(df_magma["ZSTAT"])
    return df_magma

########################################################## MAIN ###############################################################

parser = argparse.ArgumentParser(description="Convert MAGMA Z-stats to p-values")
parser.add_argument("--base_output_dir", required=True, help="Base output directory")
parser.add_argument("--gwas_name", required=True, help="GWAS name")
args = parser.parse_args()

base_output_dir = args.base_output_dir
gwas_name = args.gwas_name

print(f"Computing corrected p-values for GWAS '{gwas_name}'...")

# Load MAGMA gene results
infile = os.path.join(base_output_dir, "precomputation", gwas_name, f"{gwas_name}.resid_correct_all.gsa.genes.out")
df_magma = pd.read_csv(infile, sep=r'\s+', header=1)

# Compute p-values
df_out = get_pvals(df_magma)

# Save the results
outdir = os.path.join(base_output_dir, "precomputation")
outfile = os.path.join(outdir, gwas_name, f"{gwas_name}.resid_correct_all.gsa.genes.pvals.out")

print(f"Saving the results to {outfile}...")
df_out.to_csv(outfile, sep='\t', index=False)
print("Done.")
